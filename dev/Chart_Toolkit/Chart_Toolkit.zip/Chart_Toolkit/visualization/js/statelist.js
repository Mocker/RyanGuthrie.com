var Maps = new Object();
Maps['AK'] = { code: 'AK',
name: '',
js: 'states/AK.js'
 };
Maps['AL'] = { code: 'AL',
name: '',
js: 'states/AL.js'
};
Maps['AR'] = { code: 'AR',
name: '',
js: 'states/AR.js'
};
Maps['AZ'] = { code: 'AZ',
name: '',
js: 'states/AZ.js'
};
Maps['CA'] = { code: 'CA',
name: '',
js: 'states/CA.js'
};
Maps['CO'] = { code: 'CO',
name: '',
js: 'states/CO.js'
};
Maps['CT'] = { code: 'CT',
name: '',
js: 'states/CT.js'
};
Maps['DC'] = { code: 'DC',
name: '',
js: 'states/DC.js'
};
Maps['DE'] = { code: 'DE',
name: '',
js: 'states/DE.js'
};
Maps['FL'] = { code: 'FL',
name: '',
js: 'states/FL.js'
};
Maps['GA'] = { code: 'GA',
name: '',
js: 'states/GA.js'
};
Maps['HI'] = { code: 'HI',
name: '',
js: 'states/HI.js'
};
Maps['IA'] = { code: 'IA',
name: '',
js: 'states/IA.js'
};
Maps['ID'] = { code: 'ID',
name: '',
js: 'states/ID.js'
};
Maps['IL'] = { code: 'IL',
name: '',
js: 'states/IL.js'
};
Maps['IN'] = { code: 'IN',
name: '',
js: 'states/IN.js'
};
Maps['KS'] = { code: 'KS',
name: '',
js: 'states/KS.js'
};
Maps['KY'] = { code: 'KY',
name: '',
js: 'states/KY.js'
};
Maps['LA'] = { code: 'LA',
name: '',
js: 'states/LA.js'
};
Maps['MA'] = { code: 'MA',
name: '',
js: 'states/MA.js'
};
Maps['MD'] = { code: 'MD',
name: '',
js: 'states/MD.js'
};
Maps['ME'] = { code: 'ME',
name: '',
js: 'states/ME.js'
};
Maps['MI'] = { code: 'MI',
name: '',
js: 'states/MI.js'
};
Maps['MN'] = { code: 'MN',
name: '',
js: 'states/MN.js'
};
Maps['MO'] = { code: 'MO',
name: '',
js: 'states/MO.js'
};
Maps['MS'] = { code: 'MS',
name: '',
js: 'states/MS.js'
};
Maps['MT'] = { code: 'MT',
name: '',
js: 'states/MT.js'
};
Maps['NC'] = { code: 'NC',
name: '',
js: 'states/NC.js'
};
Maps['ND'] = { code: 'ND',
name: '',
js: 'states/ND.js'
};
Maps['NE'] = { code: 'NE',
name: '',
js: 'states/NE.js'
};
Maps['NH'] = { code: 'NH',
name: '',
js: 'states/NH.js'
};
Maps['NJ'] = { code: 'NJ',
name: '',
js: 'states/NJ.js'
};
Maps['NM'] = { code: 'NM',
name: '',
js: 'states/NM.js'
};
Maps['NV'] = { code: 'NV',
name: '',
js: 'states/NV.js'
};
Maps['NY'] = { code: 'NY',
name: '',
js: 'states/NY.js'
};
Maps['OH'] = { code: 'OH',
name: '',
js: 'states/OH.js'
};
Maps['OK'] = { code: 'OK',
name: '',
js: 'states/OK.js'
};
Maps['OR'] = { code: 'OR',
name: '',
js: 'states/OR.js'
};
Maps['PA'] = { code: 'PA',
name: '',
js: 'states/PA.js'
};
Maps['RI'] = { code: 'RI',
name: '',
js: 'states/RI.js'
};
Maps['SC'] = { code: 'SC',
name: '',
js: 'states/SC.js'
};
Maps['SD'] = { code: 'SD',
name: '',
js: 'states/SD.js'
};
Maps['TN'] = { code: 'TN',
name: '',
js: 'states/TN.js'
};
Maps['TX'] = { code: 'TX',
name: '',
js: 'states/TX.js'
};
Maps['UT'] = { code: 'UT',
name: '',
js: 'states/UT.js'
};
Maps['VA'] = { code: 'VA',
name: '',
js: 'states/VA.js'
};
Maps['VT'] = { code: 'VT',
name: '',
js: 'states/VT2.js'
};
Maps['WA'] = { code: 'WA',
name: '',
js: 'states/WA.js'
};
Maps['WI'] = { code: 'WI',
name: '',
js: 'states/WI.js'
};
Maps['WV'] = { code: 'WV',
name: '',
js: 'states/WV.js'
};
Maps['WY'] = { code: 'WY',
name: '',
js: 'states/WY.js'
};