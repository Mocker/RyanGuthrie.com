var Size = new Object();
Size['United States of America'] = { width: '800',
height: '600', left: '50', top: '50'
};
Size['AK'] = { width: '590',
height: '600', left: '50', top: '30'
};
Size['AL'] = { width: '540',
height: '550', left: '130', top: '30'
};
Size['AR'] = { width: '650',
height: '550', left: '30', top: '30'
};
Size['AZ'] = { width: '550',
height: '600', left: '30', top: '30'
};
Size['CA'] = { width: '600',
height: '650', left: '30', top: '30'
};
Size['CO'] = { width: '650',
height: '550', left: '0', top: '30'
};
Size['CT'] = { width: '650',
height: '450', left: '0', top: '30'
};
Size['DC'] = { width: '320',
height: '320', left: '200', top: '150'
};
Size['DE'] = { width: '450',
height: '450', left: '180', top: '70'
};
Size['FL'] = { width: '600',
height: '600', left: '100', top: '30'
};
Size['GA'] = { width: '550',
height: '600', left: '50', top: '30'
};
Size['HI'] = { width: '650',
height: '350', left: '50', top: '50'
};
Size['IA'] = { width: '750',
height: '600', left: '0', top: '30'
};
Size['ID'] = { width: '550',
height: '600', left: '30', top: '30'
};
Size['IL'] = { width: '550',
height: '600', left: '30', top: '30'
};
Size['IN'] = { width: '600',
height: '600', left: '30', top: '30'
};
Size['KS'] = { width: '700',
height: '450', left: '30', top: '30'
};
Size['KY'] = { width: '800',
height: '500', left: '0', top: '50'
};
Size['LA'] = { width: '600',
height: '500', left: '50', top: '30'
};
Size['MA'] = { width: '650',
height: '520', left: '50', top: '30'
};
Size['MD'] = { width: '680',
height: '420', left: '0', top: '30'
};
Size['ME'] = { width: '520',
height: '600', left: '50', top: '30'
};
Size['MI'] = { width: '680',
height: '560', left: '0', top: '30'
};
Size['MN'] = { width: '680',
height: '560', left: '0', top: '30'
};
Size['MO'] = { width: '680',
height: '560', left: '0', top: '30'
};
Size['MS'] = { width: '600',
height: '560', left: '0', top: '30'
};
Size['MT'] = { width: '680',
height: '480', left: '0', top: '50'
};
Size['NC'] = { width: '750',
height: '430', left: '0', top: '50'
};
Size['ND'] = { width: '700',
height: '480', left: '0', top: '50'
};
Size['NE'] = { width: '680',
height: '430', left: '0', top: '30'
};
Size['NH'] = { width: '580',
height: '600', left: '100', top: '30'
};
Size['NJ'] = { width: '600',
height: '600', left: '100', top: '0'
};
Size['NM'] = { width: '600',
height: '580', left: '30', top: '30'
};
Size['NV'] = { width: '700',
height: '580', left: '30', top: '30'
};
Size['NY'] = { width: '750',
height: '600', left: '30', top: '30'
};
Size['OH'] = { width: '550',
height: '600', left: '30', top: '30'
};
Size['OK'] = { width: '720',
height: '400', left: '0', top: '50'
};
Size['OR'] = { width: '650',
height: '580', left: '30', top: '30'
};
Size['PA'] = { width: '700',
height: '530', left: '0', top: '30'
};
Size['PR'] = { width: '700',
height: '530', left: '0', top: '30'
};
Size['RI'] = { width: '400',
height: '430', left: '10', top: '50'
};
Size['SC'] = { width: '700',
height: '550', left: '30', top: '30'
};
Size['SD'] = { width: '700',
height: '550', left: '0', top: '50'
};
Size['TN'] = { width: '750',
height: '310', left: '0', top: '100'
};
Size['TX'] = { width: '750',
height: '580', left: '0', top: '30'
};
Size['UT'] = { width: '500',
height: '580', left: '50', top: '30'
};
Size['VA'] = { width: '700',
height: '480', left: '0', top: '50'
};
Size['VT'] = { width: '500',
height: '580', left: '50', top: '30'
};
Size['WA'] = { width: '600',
height: '600', left: '0', top: '30'
};
Size['WI'] = { width: '580',
height: '550', left: '50', top: '30'
};
Size['WV'] = { width: '600',
height: '500', left: '50', top: '30'
};
Size['WY'] = { width: '600',
height: '530', left: '0', top: '50'
};