var Maps = new Object();
Maps['AK'] = { code: 'AK',
name: '',
js: 'states/NEWAK_lowres.js',
 };
Maps['AL'] = { code: 'AL',
name: '',
js: 'states/AL_lowres.js',
 };
Maps['AR'] = { code: 'AR',
name: '',
js: 'states/AR_lowres.js',
 };
Maps['AZ'] = { code: 'AZ',
name: '',
js: 'states/AZ_lowres.js',
 };
Maps['CA'] = { code: 'CA',
name: '',
js: 'states/CA_lowres.js',
 };
Maps['CO'] = { code: 'CO',
name: '',
js: 'states/CO_lowres.js',
 };
Maps['CT'] = { code: 'CT',
name: '',
js: 'states/CT_lowres.js',
 };
Maps['DC'] = { code: 'DC',
name: '',
js: 'states/DC_lowres.js',
 };
Maps['DE'] = { code: 'DE',
name: '',
js: 'states/DE_lowres.js',
 };
Maps['FL'] = { code: 'FL',
name: '',
js: 'states/FL_lowres.js',
 };
Maps['GA'] = { code: 'GA',
name: '',
js: 'states/GA_lowres.js',
 };
Maps['HI'] = { code: 'HI',
name: '',
js: 'states/HI_lowres.js',
 };
Maps['IA'] = { code: 'IA',
name: '',
js: 'states/IA_lowres.js',
 };
Maps['ID'] = { code: 'ID',
name: '',
js: 'states/ID_lowres.js',
 };
Maps['IL'] = { code: 'IL',
name: '',
js: 'states/IL_lowres.js',
 };
Maps['IN'] = { code: 'IN',
name: '',
js: 'states/IN_lowres.js',
 };
Maps['KS'] = { code: 'KS',
name: '',
js: 'states/KS_lowres.js',
 };
Maps['KY'] = { code: 'KY',
name: '',
js: 'states/KY_lowres.js',
 };
Maps['LA'] = { code: 'LA',
name: '',
js: 'states/LA_lowres.js',
 };
Maps['MA'] = { code: 'MA',
name: '',
js: 'states/MA_lowres.js',
 };
Maps['MD'] = { code: 'MD',
name: '',
js: 'states/MD_lowres.js',
 };
Maps['ME'] = { code: 'ME',
name: '',
js: 'states/ME_lowres.js',
 };
Maps['MI'] = { code: 'MI',
name: '',
js: 'states/MI_lowres.js',
 };
Maps['MN'] = { code: 'MN',
name: '',
js: 'states/MN_lowres.js',
 };
Maps['MO'] = { code: 'MO',
name: '',
js: 'states/MO_lowres.js',
 };
Maps['MS'] = { code: 'MS',
name: '',
js: 'states/MS_lowres.js',
 };
Maps['MT'] = { code: 'MT',
name: '',
js: 'states/MT_lowres.js',
 };
Maps['NC'] = { code: 'NC',
name: '',
js: 'states/NC_lowres.js',
 };
Maps['ND'] = { code: 'ND',
name: '',
js: 'states/ND_lowres.js',
 };
Maps['NE'] = { code: 'NE',
name: '',
js: 'states/NE_lowres.js',
 };
Maps['NH'] = { code: 'NH',
name: '',
js: 'states/NH_lowres.js',
 };
Maps['NJ'] = { code: 'NJ',
name: '',
js: 'states/NJ_lowres.js',
 };
Maps['NM'] = { code: 'NM',
name: '',
js: 'states/NM_lowres.js',
 };
Maps['NV'] = { code: 'NV',
name: '',
js: 'states/NV_lowres.js',
 };
Maps['NY'] = { code: 'NY',
name: '',
js: 'states/NY_lowres.js',
 };
Maps['OH'] = { code: 'OH',
name: '',
js: 'states/OH_lowres.js',
 };
Maps['OK'] = { code: 'OK',
name: '',
js: 'states/OK_lowres.js',
 };
Maps['OR'] = { code: 'OR',
name: '',
js: 'states/OR_lowres.js',
 };
Maps['PA'] = { code: 'PA',
name: '',
js: 'states/PA_lowres.js',
 };
Maps['PR'] = { code: 'PR',
name: '',
js: 'states/PR_lowres.js',
 };
Maps['RI'] = { code: 'RI',
name: '',
js: 'states/RI_lowres.js',
 };
Maps['SC'] = { code: 'SC',
name: '',
js: 'states/SC_lowres.js',
 };
Maps['SD'] = { code: 'SD',
name: '',
js: 'states/SD_lowres.js',
 };
Maps['TN'] = { code: 'TN',
name: '',
js: 'states/TN_lowres.js',
 };
Maps['TX'] = { code: 'TX',
name: '',
js: 'states/TX_lowres.js',
 };
Maps['UT'] = { code: 'UT',
name: '',
js: 'states/UT_lowres.js',
 };
Maps['VA'] = { code: 'VA',
name: '',
js: 'states/VA_lowres.js',
 };
Maps['VT'] = { code: 'VT',
name: '',
js: 'states/VT_lowres.js',
 };
Maps['WA'] = { code: 'WA',
name: '',
js: 'states/WA_lowres.js',
 };
Maps['WI'] = { code: 'WI',
name: '',
js: 'states/WI_lowres.js',
 };
Maps['WV'] = { code: 'WV',
name: '',
js: 'states/WV_lowres.js',
 };
Maps['WY'] = { code: 'WY',
name: '',
js: 'states/WY_lowres.js',
 };
